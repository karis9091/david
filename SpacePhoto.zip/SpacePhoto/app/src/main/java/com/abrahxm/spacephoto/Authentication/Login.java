package com.abrahxm.spacephoto.Authentication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.abrahxm.spacephoto.R;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}